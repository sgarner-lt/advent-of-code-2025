# Raw Idea

Language Toolchain Setup — Install and verify all 5 language toolchains (Rust 1.83.0+, Gleam 1.13.0+, Roc nightly, Carbon experimental, Bosque research) with build tools and testing frameworks working correctly
