# Raw Idea: Project Structure Initialization

**Feature Size:** XS

**Description:**

Create standardized directory structure with dayXX/ folders containing language-specific subdirectories (rust/, roc/, gleam/, carbon/, bosque/) and shared input files.
